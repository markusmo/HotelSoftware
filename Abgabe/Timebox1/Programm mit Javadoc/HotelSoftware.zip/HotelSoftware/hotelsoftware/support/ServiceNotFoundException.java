package hotelsoftware.support;

/**
 * Wird geworfen, wenn ein Service nicht gefunden wird.
 *
 * @author Tobias
 */
public class ServiceNotFoundException extends Exception
{
    public ServiceNotFoundException()
    {
    }
}
