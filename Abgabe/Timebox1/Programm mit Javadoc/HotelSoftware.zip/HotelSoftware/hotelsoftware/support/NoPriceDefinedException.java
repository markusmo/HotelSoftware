/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelsoftware.support;

/**
 *Diese Fehlermeldung erscheint, falls für einen Raum kein Preis Definiert wurde
 * @author Dunst
 */
public class NoPriceDefinedException extends Exception
{

    public NoPriceDefinedException()
    {
    }
    
}
