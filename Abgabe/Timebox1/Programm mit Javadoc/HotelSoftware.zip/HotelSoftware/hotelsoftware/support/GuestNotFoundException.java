package hotelsoftware.support;
/**
 * Fehlermeldung die auftritt wenn ein Gast nicht gefunden wird
 * @author Hubert
 *
 */
public class GuestNotFoundException extends Exception {

	public GuestNotFoundException() {
		// TODO Auto-generated constructor stub
	}
}
