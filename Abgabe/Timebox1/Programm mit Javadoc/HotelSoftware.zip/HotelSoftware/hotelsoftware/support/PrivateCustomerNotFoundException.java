package hotelsoftware.support;

/**
 * Fehlerlmeldung die auftritt, wenn ein Kunde nicht gefunden wird
 *
 * @author Hubert
 *
 */
public class PrivateCustomerNotFoundException extends Exception
{

    public PrivateCustomerNotFoundException()
    {
        // TODO Auto-generated constructor stub
    }
}
