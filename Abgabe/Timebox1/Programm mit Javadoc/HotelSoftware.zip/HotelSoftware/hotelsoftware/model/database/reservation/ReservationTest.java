package hotelsoftware.model.database.reservation;

import java.util.Collection;

/**
 *Diese Klasse enthällt Tests für die Reservation
 * @author Tobias
 */
public class ReservationTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Reservation Tests
        //DBReservation testReservation = DBReservation.getReservationByNumber(1234); //funktioniert
        //DBReservation testReservation = DBReservation.getReservationById(2); //funktioniert
        //Collection<DBReservation> testReservation = DBReservation.getReservationsByName("Stefan", "Dunst"); //funktioniert
        //Collection<DBReservation> testReservation = DBReservation.getAllReservations(); //funktioniert nicht
        //Collection<DBReservation> testReservation = DBReservation.getReservationsByNameApprox("Stef", "Du"); //funktioniert
        //int guestAmount = testReservation.getGuestAmount();   //funktioniert
        
        
    }
}
