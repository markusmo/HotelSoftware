/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelsoftware.model.database.parties;

import hotelsoftware.model.database.reservation.DBReservation;
import java.util.Collection;
import java.util.List;

/**
 *Diese Klasse dient zum Test der Party Klasse
 * @author Tobias
 */
public class PartiesTest {

    /**
     * Main-Klasse für Testzwecke
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //DBPrivateCustomer Tests
        //DBPrivateCustomer testCustomer = DBPrivateCustomer.getPrivateCustomerByName("Hans", "Guck"); //funktioniert
        //System.out.println(testCustomer.getFname());
        
        //DBGuest Tests
        //Collection<DBGuest> testGuest = DBGuest.getGuestsByName("Stefan", "Dunst"); //funktioniert
        //DBGuest testGuest = DBGuest.getGuestFromReservationNumber("1234");    //funktioniert
        
        //DBCompanyType Tests
        //List<DBCompanyType> testCompanyTypes = DBCompanyType.getAllTypes();   //funktioniert
        
        //DBCompany Tests
        //DBCompany testCompany = DBCompany.getCompanyByName("Reiselust");  //funktioniert
        
        
    }
}
