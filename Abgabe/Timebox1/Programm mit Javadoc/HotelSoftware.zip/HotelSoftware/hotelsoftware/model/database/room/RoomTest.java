/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelsoftware.model.database.room;

import java.util.Collection;

/**
 *Diese Klasse dient zum Testen Der DBRoom Klassen
 * @author Tobias
 */
public class RoomTest {

    /**
     * Mainclass zum testen
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //DBRoom Tests
        //DBRoom testRoom = DBRoom.getRoomByNumber("101"); //funktioniert
        //Collection<DBRoom> testRooms = DBRoom.getRoomsByCategory(DBRoomCategory.getRoomCategoryByName("Familienzimmer")); //funktioniert nicht
        
        //DBRoomCategory Tests
        //Collection<DBRoomCategory> testCategories = DBRoomCategory.getAllCategories();    //funktioniert
        //DBRoomCategory testCategory = DBRoomCategory.getRoomCategoryByName("Familienzimmer");
        Collection<DBRoomCategory> testCategories; 
    }
}
