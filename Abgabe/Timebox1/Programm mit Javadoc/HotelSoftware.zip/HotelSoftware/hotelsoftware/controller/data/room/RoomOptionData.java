package hotelsoftware.controller.data.room;

/**
 *Dieses Interface enthält alle wichtigen Informationen für die Klasse RoomOption 
 * @author Lins Christian (christian.lins87@gmail.com)
 */
public interface RoomOptionData
{

    String getName();
    
}
