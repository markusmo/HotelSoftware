/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelsoftware.controller.data.parties;

/**
 *Dieses Interface stellt die Methoden für die Land-Klasse zur verfügung
 * @author Dunst
 */
public interface CountryData
{
    public Integer getId();

    public String getName();

    public String toString();
}
