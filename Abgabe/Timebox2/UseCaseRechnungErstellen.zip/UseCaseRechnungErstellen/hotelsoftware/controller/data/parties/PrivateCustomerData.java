/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelsoftware.controller.data.parties;

/**
 *
 * @author Dunst
 */
public interface PrivateCustomerData extends CustomerData
{

    String getFname();

    String getLname();
    
}
