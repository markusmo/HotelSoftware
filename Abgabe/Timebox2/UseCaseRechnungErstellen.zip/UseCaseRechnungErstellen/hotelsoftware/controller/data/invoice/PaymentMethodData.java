package hotelsoftware.controller.data.invoice;

/**
 * Dieses Interface wird an die GUI weitergeleitet.
 * @author Lins Christian (christian.lins87@gmail.com)
 */
public interface PaymentMethodData
{

    String getMethod();
    
}
