/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelsoftware.controller.data.room;

/**
 *Dieses Interface enthält alle wichtigen Methoden für die Klasse RoomStatus
 * @author Lins Christian (christian.lins87@gmail.com)
 */
public interface RoomStatusData
{

    String getStatusName();
    
}
