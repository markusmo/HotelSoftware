/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelsoftware.controller.data.users;

/**
 * dieses Interface stellt alle wichtigen Methoden für die Klasse Permission da
 * @author Lins Christian (christian.lins87@gmail.com)
 */
public interface PermissionData
{

    String getName();
    
}
