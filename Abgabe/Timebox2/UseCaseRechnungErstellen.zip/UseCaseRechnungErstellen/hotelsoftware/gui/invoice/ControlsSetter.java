/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelsoftware.gui.invoice;

/**
 *
 * @author Lins Christian (christian.lins87@gmail.com)
 * 
 * Diese Methode kann vom Controler aufgerufen werden, um die für den Control-Setter interessanten Buttons zu setzten
 */
public interface ControlsSetter
{
    public void setControls();
    
}
