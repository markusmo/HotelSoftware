package hotelsoftware.gui.invoice.invoiceHome;

import hotelsoftware.controller.data.parties.GuestData;
import hotelsoftware.controller.data.service.HabitationData;
import java.awt.event.KeyListener;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Lins Christian (christian.lins87@gmail.com)
 * 
 * Tabelle für die Aufenthalte
 * 
 */
public class habitations extends javax.swing.JPanel
{
    private static final int columnCount = 5;
    
    //FIXME diese Daten und auch viele Funktionen, die hier stehen, werden in Zukunft in einem eigenen TableModel gehalten!
    private HabitationData[] data = new HabitationData[0];

    
    public habitations(KeyListener parent)
    {
        initComponents();
        habitations.addKeyListener(parent);
    }
    
    public habitations(String labelName)
    {
        initComponents();
        HabitationsLabel.setText(labelName);
    }

    public habitations()
    {
        initComponents();
    }

    /**
     * erzeugt einen Array aus der Daten-Kollektion
     * @return Daten für die Tabelle (JTable)
     */
    private Object[][] getDataArray()
    {
        Object[][] objectArray = new Object[data.length][columnCount];

        int i = 0;
        for (HabitationData hab : data)
        {
            String[] rowData = getRowData(hab);
            for (int j = 0; j < columnCount; j++)
            {
                objectArray[i][j] = rowData[j];
            }
            i++;
        }
        return objectArray;
    }

    public int getRowCount()
    {
        return habitations.getRowCount();
    }

    /**
     * erzeugt einen Aufenthalt für die Tabelle
     * 
     * @param data
     * @return 
     */
    private String[] getRowData(HabitationData data)
    {
        Collection<GuestData> guests = data.getGuestsData();
        String[] rowData = new String[columnCount];
        for (GuestData guest : guests)
        {
            rowData[0] = guest.getLname();
            rowData[1] = guest.getFname();
            rowData[2] = data.getRoomsData().getNumber();
            rowData[3] = data.getStart().toString();
            rowData[4] = data.getEnd().toString();
        }
        return rowData;
    }

    /**
     * setzt die Tabelle mit den neuen Daten
     * alte Daten werden überschrieben
     * 
     * @param data 
     */
    public void setTable(Collection<HabitationData> data)
    {
        if (data != null)
        {
            if (this.data != null)
            {
                // �berpr�fe doppelte Eintr�ge
                LinkedList<HabitationData> origin = new LinkedList((List<HabitationData>) Arrays.asList(this.data));

                for (HabitationData item : data)
                {
                    if (!origin.contains(item))
                    {
                        origin.add(item);
                    }
                }
                // setze adaptiere Liste
                this.data = origin.toArray(new HabitationData[origin.size()]);
            }
            else
            {
                this.data = data.toArray(new HabitationData[data.size()]);
            }
        }
        else
        {
            if (this.data == null)
            {
                this.data = new HabitationData[0];
            }
        }
        this.habitations.setModel(new DefaultTableModel(getDataArray(), new String[]
                {
                    "Last name", "First name", "Room Nr", "Arrival", "Departure"
                }){
                    @Override
                    public boolean isCellEditable(int row, int column)
                    {
                        return false;
                    }
                });
    }

    /**
     * löscht die aktuelle Tabelle
     * 
     * @return alle Inhalte, die gelöscht werden 
     */
    public Collection<HabitationData> clearTable()
    {
        List<HabitationData> removed = Arrays.asList(data);

        this.data = new HabitationData[0];
        this.habitations.setModel(new DefaultTableModel(getDataArray(), new String[]
                {
                    "Last name", "First name", "Room Nr", "Arrival", "Departure"
                }));

        return removed;
    }

    /**
     * 
     * @return alle Aufenthalte, die selektiert sind
     */
    public Collection<HabitationData> getSelectedRows()
    {
        int[] selectedRows = habitations.getSelectedRows();
        Collection<HabitationData> result = new LinkedList();

        for (Integer row : selectedRows)
        {
            result.add(data[row]);
        }
        return result;
    }

    /**
     * This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        habitations = new javax.swing.JTable();
        HabitationsLabel = new javax.swing.JLabel();

        habitations.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Last name", "First name", "Room Nr", "Arrival", "Departure"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(habitations);

        HabitationsLabel.setText("Habitations");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(HabitationsLabel)
                .addContainerGap(495, Short.MAX_VALUE))
            .addComponent(jScrollPane2)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(HabitationsLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 395, Short.MAX_VALUE)
                .addGap(18, 18, 18))
        );
    }// </editor-fold>//GEN-END:initComponents
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel HabitationsLabel;
    private javax.swing.JTable habitations;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables

    /**
     * entfernt die Ausgewählten Reihen
     * 
     * @return die zu entfernenden Reihen 
     */
    Collection<HabitationData> removeSelectedRows()
    {
        Collection<HabitationData> removed = getSelectedRows();

        int[] selectedRows = habitations.getSelectedRows();

        Collection<HabitationData> newData = new LinkedList();

        for (int i = 0; i < data.length; i++)
        {
            boolean isSelected = false;
            for (int j = 0; j < selectedRows.length; j++)
            {
                if (selectedRows[j] == i)
                {
                    isSelected = true;
                }
            }
            if (!isSelected)
            {
                newData.add(data[i]);
            }
        }

        clearTable();
        setTable(newData);

        return removed;
    }

    /**
     * 
     * @return alle Daten der Tabelle
     */
    Collection<HabitationData> getRows()
    {
        return Arrays.asList(data);
    }

    void setFocus()
    {
        habitations.requestFocus();
    }
}
