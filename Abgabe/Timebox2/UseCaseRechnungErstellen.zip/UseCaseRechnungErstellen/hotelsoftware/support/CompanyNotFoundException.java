package hotelsoftware.support;
/**
 * Fehlermeldung die auftritt wenn eine Firma nicht gefunden wird
 * @author Hubert
 *
 */
public class CompanyNotFoundException extends Exception {

	public CompanyNotFoundException() {

	}
}
