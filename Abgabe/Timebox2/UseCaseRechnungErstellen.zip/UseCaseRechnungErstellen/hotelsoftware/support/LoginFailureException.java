package hotelsoftware.support;

/**
 * Wird geworfen, wenn der Login fehlschlaegt.
 * @author Dunst
 */
public class LoginFailureException extends Exception
{

    public LoginFailureException()
    {
    }
    
}
