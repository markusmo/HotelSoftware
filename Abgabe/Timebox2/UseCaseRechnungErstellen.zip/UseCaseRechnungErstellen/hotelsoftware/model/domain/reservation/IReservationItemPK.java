/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelsoftware.model.domain.reservation;

/**
 *
 * @author Kno
 */
public interface IReservationItemPK {

    Integer getIdReservations();

    Integer getIdRoomCategories();

    void setIdReservations(int idReservations);

    void setIdRoomCategories(int idRoomCategories);
    
}
