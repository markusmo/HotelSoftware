/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelsoftware.model.domain.room;

/**
 *
 * @author Kno
 */
public interface IRoomCategoryPricePK {

    Integer getIdRoomCategories();

    Integer getIdSeasons();

    void setIdRoomCategories(int idRoomCategories);

    void setIdSeasons(int idSeason);
    
}
